<?php 
    include 'config.php';
    session_start();
    if(isset($_POST['username']) && isset($_POST['password'])){
        if($_POST['username']==="butbibutmay" && $_POST['password']===$admin_pw){
            die('Here is your flag: '.$Flag);
        } else {
            die('Incorrect username/password');
        }
    }

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9">
    
    <title>Viettel Private Game Server</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=1">
    <meta name="description" content="Viettel provides open source server and client software for messaging and collaboration. To find out more visit http://www.viettel.com.vn">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" type="text/css" href="css/common,login,zhtml,skin.css">
	
    <link rel="SHORTCUT ICON" href="img/favicon.ico">
    
    
</head>

<body>	
	<div class="LoginScreen">
		
		<div class="center">
			<div class="contentBox">
				<div class="ImgAltBanner"></div>
				<h1><a href="index.php" target="_new">
					<span class="ImgLoginBanner"></span>
				</a></h1>
				<div id="ZLoginAppName">Web Client</div>
                
                                <form method="post" name="loginForm" action="index.php" accept-charset="UTF-8">
                                <input type="hidden" name="loginOp" value="login">
                    
				<table class="form">
                    
                                                <tbody><tr>
                                                    <td><label for="username">Username:</label></td>
                                                    <td><input id="username" class="zLoginField" name="username" type="text" value="" size="40" maxlength="1024" autocapitalize="off" autocorrect="off"></td>
                                                </tr>
                                            
                                        <tr>
                                            <td><label for="password">Password:</label></td>
                                            <td><input id="password" autocomplete="off" class="zLoginField" name="password" type="password" value="" size="40" maxlength="1024"></td>
                                        </tr>
                            
                                        <tr>
                                            <td>&nbsp;</td>
                                            <td class="submitTD">
                                                
                                                <input type="submit" class="ZLoginButton DwtButton" value="Sign In">
                                            </td>
                                        </tr>
                        
					<tr>
						<td colspan="2"><hr></td>
					</tr>
					<tr>
						<td>
							<label for="client">Version:</label>
						</td>
						<td>
							<div class="postioning">
                                
                                        <select id="client" name="client" onchange="clientChange(this.options[this.selectedIndex].value)">
                                            <option value="preferred" selected=""> Default</option>
                                        </select>
                                    

</script><a href="source" id="ZLoginWhatsThisAnchor"><b>Source</b></a>
									<div id="ZLoginWhatsThis" class="ZLoginInfoMessage" style="display:none;"><center style="margin-bottom:3px;"><b>Client Types:</b></center>	<b>Advanced</b> offers the full set of Web collaboration features. This Web Client works best with newer browsers and faster Internet connections. <br><br><b>Standard</b> is recommended when Internet connections are slow, when using older browsers, or for easier accessibility. <br><br><b>Mobile</b> is recommended for mobile devices. <br><br>To set <b>Default</b> to be your preferred client type, change the sign in options in your Preferences, General tab after you sign in.</div>
									<div id="ZLoginUnsupported" class="ZLoginInfoMessage" style="display:none;">Note that your web browser or display does not fully support the Advanced version.  We strongly recommend that you use the Standard client.</div>
								</div>
							</td>
						</tr>
                        <tr>
                            <td colspan="2">
                                <a href="forgot.php" style="color:white;">Forgot admin password?</a>
                            </td>
					    </tr>
					</tbody></table>
			</form></div>
			<div class="decor1"></div>
		</div>

		<div class="Footer">				

			<div class="copyright">
            Copyright (c) 2009-2014 Zimbra, Inc.Powered by Zimbra Open Source Edition,
                             <a href="#"> Zimbra</a>
                             
                
			</div>
        </div>
		<div class="decor2"></div>
	</div>                                 


</body></html>