<?php 
    error_reporting(0);
    include 'config.php';
    include 'db.php';
    session_start();

    function make_token(){
        global $key;
        $salt = "^*@&24";
        srand((int)($salt.$key));
		$token = "";
        for($i = 0; $i < 32; $i++) {
            $randomDigit = (string)rand() % 10;
            $token .= "," . $randomDigit;
        }
        $token = str_replace(",", "", $token);
        return $token;
    }

    if(isset($_POST['username'])){
        $usn = (string)$_POST['username'];
        if($usn === 'butbibutmay'){
            $token = make_token();
            savedb(session_id(),$token);
            die("Token sent to butbibutmay's email. Please visit link 'forgot.php?verify_token=[The token you received]' to get password!");
        } else {
            die('Invalid username');
        }
    }

    if(isset($_GET['verify_token'])){
        $t = (string)$_GET['verify_token'];
        verify_token(session_id(),$t);
    }


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9">
    
    <title>Viettel Private Game Server</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=1">
    <meta name="description" content="Viettel provides open source server and client software for messaging and collaboration. To find out more visit http://www.viettel.com.vn">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" type="text/css" href="css/common,login,zhtml,skin.css">
	
    <link rel="SHORTCUT ICON" href="img/favicon.ico">
    
    
</head>

<body>	
	<div class="LoginScreen">
		
		<div class="center">
			<div class="contentBox">
				<div class="ImgAltBanner"></div>
				<h1><a href="index.php" target="_new">
					<span class="ImgLoginBanner"></span>
				</a></h1>
				<div id="ZLoginAppName">Web Client</div>
                
                                <form method="post" name="loginForm" action="forgot.php" accept-charset="UTF-8">
                                <input type="hidden" name="loginOp" value="login">
                    
				<table class="form">
                    
                                                <tbody><tr>
                                                    <td><label for="username">Username:</label></td>
                                                    <td><input id="username" placeholder="butbibutmay" style="padding-left:3px;" class="zLoginField" name="username" type="text" value="" size="40" maxlength="1024" autocapitalize="off" autocorrect="off"></td>
                                                </tr>
                            
                                        <tr>
                                            <td>&nbsp;</td>
                                            <td class="submitTD">
                                                <input type="submit" class="ZLoginButton DwtButton" value="Reset">
                                            </td>
                                        </tr>
                        
					<tr>
						<td colspan="2"><hr></td>
					</tr>
                    <tr>
                            <td colspan="2">
                                <a href="index.php" style="color:white;">Back</a>
                            </td>
					    </tr>

					</tbody></table>
			</form></div>
			<div class="decor1"></div>
		</div>

		<div class="Footer">				

			<div class="copyright">
            Copyright (c) 2009-2014 Zimbra, Inc.Powered by Zimbra Open Source Edition,
                             <a href="#"> Zimbra</a>
                             
                
			</div>
        </div>
		<div class="decor2"></div>
	</div>                                 



</body></html>
